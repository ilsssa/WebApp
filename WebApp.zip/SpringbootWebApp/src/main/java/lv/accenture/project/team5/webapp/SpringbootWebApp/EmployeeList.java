package lv.accenture.project.team5.webapp.SpringbootWebApp;

import java.util.ArrayList;
import java.util.List;

public class EmployeeList {

	public List<Employee>  getEmployeeList(){
		List<Employee> listOfEmployees = new ArrayList<Employee>();
	//need to connect to database to get list of employees
	//CRUD approach here?
		
		
	//for testing purposes we can make the list manually
		listOfEmployees.add(new Employee(1,"Adam","Bush","manager"));
		listOfEmployees.add(new Employee(2,"Sara","Watson","regular"));
		listOfEmployees.add(new Employee(3,"Amin","Yashed","admin"));
		listOfEmployees.add(new Employee(4,"Dina","Soar","regular"));

	//26:55 to continue in youtube 
	// https://www.youtube.com/watch?v=bq0j8ha410U
	
		
		
		return listOfEmployees;
	}
}
